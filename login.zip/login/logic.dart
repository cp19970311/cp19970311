import 'package:best_flutter_ui_templates/utils/sp_utils.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:local_auth/local_auth.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../routes/route_name.dart';
import '../font_page/view.dart';
import 'state.dart';
import 'dart:io';

class LoginLogic extends GetxController {
  final LoginState state = LoginState();

  final LocalAuthentication auth = LocalAuthentication();


  @override
  void onInit() {
    // TODO: implement onInit
    getEquipmentType();
    getCheckBiometricsInfo();
    // isLocalAuth();
    // getBioStatus();
    // showBioAuthDialogIfNeeded();
    super.onInit();
  }


  // void showBioAuthDialogIfNeeded() async {
  //   bool shouldShowBioAuthDialog = await SpUtils.getBioStatus();
  //   if (shouldShowBioAuthDialog) {
  //     goCheckBiometrics(); // 显示生物识别验证框
  //   } else {
  //     Get.toNamed(RouteName.guidePages); // 不显示生物识别验证框，直接跳转到下一个页面
  //   }
  // }



  /// 获取设备信息 判断是ios还是安卓
  void getEquipmentType(){
    if (Platform.isAndroid) {
      print('Android 操作系统');
      state.mobileType.value = 'android';
    } else if (Platform.isIOS) {
      print('iOS 操作系统');
      state.mobileType.value = 'ios';
    } else {
      print('其他操作系统');
    }
  }

  ///检查是否支持生物识别
  Future<void> getCheckBiometricsInfo() async {
    ///是否支持生物识别
    final bool canAuthenticateWithBiometrics = await auth.canCheckBiometrics;
    ///是否支持生物识别 或者 设备级身份验证
    final bool canAuthenticate = canAuthenticateWithBiometrics || await auth.isDeviceSupported();

    ///如果支持
    if(canAuthenticate){
      ///获取已登记的生物特征列表
      final List<BiometricType> availableBiometrics = await auth.getAvailableBiometrics();

      if (availableBiometrics.isNotEmpty) {
        // Some biometrics are enrolled.
        state.faceState.value = true;
        print('指纹或面部');
        print("availableBiometrics == ${availableBiometrics}");
        goCheckBiometrics();
      }else{
        state.faceState.value = false;
        print('前去密码登录');
      }
    }
  }

  void navigateToNextPage() async {
    // 第二次登录输入密码之后跳到首页
    Get.offAndToNamed(RouteName.guidePages);

    // 等待2秒之后跳转到下一个页面
    await Future.delayed(const Duration(seconds: 2));

    // 跳转到需要开启人脸识别或者是指纹解锁页
    Get.offAndToNamed(RouteName.facePage); // Replace 'RouteName.anotherPage' with the actual route
  }



  Future<void> goCheckBiometrics() async {
    state.faceLoginState.value = await auth.authenticate(
        localizedReason: 'Please verify to unlock the application',
        options: const AuthenticationOptions(biometricOnly: true));
    if(state.faceLoginState.value){
      print('登录成功');
      navigateToNextPage();
      Get.offAndToNamed(RouteName.guidePages);
    }else{
      print('登录失败');
    }
  }
  Future<void> goCheckBiometri() async {
    state.biologyState.value = await auth.authenticate(
        localizedReason: 'Please verify to unlock the application',
        options: const AuthenticationOptions(biometricOnly: true));
    if(state.biologyState.value){
      print('登录成功');
      navigateToNextPage();
      Get.offAndToNamed(RouteName.guidePages);
    }else{
      print('登录失败');
    }
  }
  void modeSwitching(){
    state.modeSwitch.value =! state.modeSwitch.value;
    print(state.modeSwitch.value );
  }
  //拿到本地存储的密码，进行校验
  final TextEditingController passwordController = TextEditingController();

  Future<String> _getSavedPassword() async {
    String password = await SpUtils.getString('password');
    return password;
  }
  final focusNodeConfirm = FocusNode();
  //显示与隐藏密码框提示文本
  final showErrorText = false.obs;
  // 获取生物识别状态
  void getBioStatus() async {
    state.status.value = await SpUtils.getBioStatus();
  }




  
  void checkPassword({required String inputPassword}) async {
    String savedPassword = await _getSavedPassword();
    if (inputPassword == savedPassword) {
      print('密码正确');
      // 导航到下一个页面
      Get.offAndToNamed(RouteName.guidePages);
    } else {
      print('密码错误');
      // 显示错误消息或执行其他操作
      state.passwordLoginState.value =false;
    }
  }


  //身份识别方法
  @override
  void isLocalAuth() async{
    final LocalAuthentication auth = LocalAuthentication();
    final bool canCheckBiometrics = await auth.canCheckBiometrics;
    if (canCheckBiometrics) {
      final bool isAuthorized = await auth.authenticate(
        localizedReason: 'Please authenticate to complete the transaction.',
        options: const AuthenticationOptions(
          stickyAuth: true,
          biometricOnly: true,
        ),
      );
      if (isAuthorized) {
        // authorized successfully, do something here
        Get.toNamed(RouteName.guidePages);
      } else {
        // failed to authenticate, show an error message
        print('nook');
      }
    }else{
      print('no face');
    }
  }

  //验证方式切换
  void selectValidatorType(){
    state.IdentMethod.value = state.IdentMethod.value == 'face'? 'password':'face';
  }

  //在用户点击confirm按钮时，调用Sputils。setBio将用户的选择保存在本地
  void onConfirmButtonPressed() async {
    await SpUtils.setBioStatus(true);
    // 执行其他操作，如跳转到下一个页面
  }

  //在用户点击按钮时，调用Sputils。setBio将用户的选择保存在本地
  void onCancelButtonPressed() async {
    await SpUtils.setBioStatus(false);
    // 执行其他操作，如跳转到下一个页面
    Get.toNamed(RouteName.guidePages);
  }
}
