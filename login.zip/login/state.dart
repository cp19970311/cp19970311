import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:local_auth/local_auth.dart';

class LoginState {
  late FocusNode focusNodePassFir; //第一个焦点节点

  late RxBool faceState;  //面部是否可用
  late RxBool passwordLoginState; //密码登录是否正确
  late RxBool modeSwitch; //面部可用切换状态
  late RxString IdentMethod;
  late RxString mobileType ; //设备类型
  late RxBool faceLoginState; //面部登录状态
  late RxBool biologyState;//指纹登录状态

  late RxBool status;  // 是否开启生物识别
  late RxBool bioSupport;  //生物支持是否可用
  late LocalAuthentication auth ;  //生物识别


  LoginState() {
    ///Initialize variables
    focusNodePassFir = FocusNode();
    faceState =false.obs;
    passwordLoginState = true.obs;
    modeSwitch = true.obs;
    mobileType = ''.obs;
    faceLoginState = false.obs;
    biologyState=false.obs;
    IdentMethod = 'face'.obs;
    status = false.obs;
    bioSupport = false.obs;
    auth = LocalAuthentication();
  }
}
