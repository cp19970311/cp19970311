import 'package:animate_do/animate_do.dart';
import 'package:best_flutter_ui_templates/constants/text_style_constants.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:gradient_borders/box_borders/gradient_box_border.dart';
import 'package:local_auth/local_auth.dart';
import 'package:pin_input_text_field/pin_input_text_field.dart';

import '../../constants/color_constants.dart';
import '../../public_controller/color_controller.dart';
import '../../utils/sp_utils.dart';
import 'logic.dart';

class Face_recognitionPage extends StatelessWidget {

  final logic = Get.put(LoginLogic());
  final state = Get
      .find<LoginLogic>()
      .state;
  final colorController = Get.find<ColorController>();
  @override
  Widget build(BuildContext context) {
    double pageWidth = MediaQuery
        .of(context)
        .size
        .width;
    double pageHeight = MediaQuery
        .of(context)
        .size
        .height;

    return Scaffold(
      backgroundColor: colorController.backgroundColor,
      body: Container(
        color: Colors.black.withOpacity(0.6),
        width: pageWidth,
        height: pageHeight,
        alignment: Alignment.bottomCenter,
        child: Obx(() {
          return checkBiometricsBox(context);
        }),
      ),
    );
  }

  Widget checkBiometricsBox(BuildContext context) {
    if (state.faceState.value) {
      if (state.modeSwitch.value) {
        return faceBox(context);
      } else {
        return passwordBox(context);
      }
    } else if(state.status.value){
      return finger(context);
    }else{
      return passwordBox(context);
    }
  }


  //面部识别组件
  Widget faceBox(BuildContext context) {
    return SlideInUp(
      child: Container(
        height: 468.h,
        decoration: BoxDecoration(
          color: Color(0xFFF7F7F7),
          borderRadius: BorderRadius.only(
              topRight: Radius.circular(24.r),
              topLeft: Radius.circular(24.r)
          ),

        ),
        child: Column(
          children: [
            //头部横杠
            Container(
              margin: EdgeInsets.only(top: 16.h),
              width: 56.w,
              height: 5.h,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(90.r),
                  color: Color(0xFFbacE8E8E8)
              ),
            ),
            ///标题 和关闭按钮
            Container(
              height: 32.h,
              margin: EdgeInsets.only(top: 29.h,),
              child: Row(
                children: [

                  Expanded(
                    flex: 1,
                    child: GestureDetector(
                      onTap: () {
                        print('密码登录');
                        logic.modeSwitching();
                      },
                      child: SvgPicture.asset('assets/wallet_page/fingerboard.svg',
                        width: 32.w,),),),
                  Expanded(
                      flex: 1,
                      child: Obx(() {
                        return FittedBox(
                            child: Text(
                                state.mobileType.value == 'android' ? 'Fingerprint_Verification'.tr : 'Face_Verification'.tr,
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontWeight: FontWeight.w700,
                                  fontSize: 18.sp,
                                  color: colorController.textColor,
                                )
                            )
                        );
                      })),
                  Expanded(
                      flex: 1,
                      child: GestureDetector(
                        onTap: () {
                          Navigator.pop(context);
                        },
                        child: Container(
                          padding: EdgeInsets.only(right: 23.w),
                          alignment: Alignment.centerRight,
                          child: Container(
                            child: SvgPicture.asset('assets/wallet_page/x.svg',
                              width: 24.w,),
                          ),
                        ),
                      )),
                ],
              ),
            ),

            /// 中间图标和文字
            Container(
              // height: 160.h,
              margin: EdgeInsets.only(bottom: 47.h, top: 47.h),
              child: Column(
                children: [
                  GestureDetector(
                      onTap: (){
                        logic.goCheckBiometrics();
                      },
                      child:Image.asset(
                        state.mobileType.value == 'android' ? 'assets/images/recognition.png' : 'assets/images/faceId_icon.png',
                        width: 95.w,)),
                  SizedBox(height: 17.h,),
                  Container(
                    width: 225.w,
                    child: Text(
                      state.mobileType.value == 'android' ? 'Fingerprint'.tr : 'Face'.tr,

                      textAlign:TextAlign.center,
                      style: TextStyle(fontSize: 12.sp,fontWeight: FontWeight.w600,color: colorController.textColor),),
                  ),
                  SizedBox(height: 20.h,),
                  Container(
                    height: 20.h,
                    alignment: Alignment.center,
                    child: Obx(() {
                      return
                        !state.faceLoginState.value ?
                        Text(
                          '验证失败，请重新验证',
                          style: XTextStyle.super_8(
                              XColor.neutral13),
                        ) : SizedBox();
                    }),
                  ),
                  GestureDetector(
                    onTap: () {
                    },
                    child: Container(
                      // margin: EdgeInsets.only(bottom: 35.h),
                      width: 352.w,
                      height: 48.h,
                      decoration: BoxDecoration(
                        color: Color(0xFFFF5E0F),
                        borderRadius: BorderRadius.all(Radius.circular(6.r)),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            child: Text(
                              'Confirm'.tr,
                              style: TextStyle(
                                  fontSize: 14.sp,
                                  color: colorController.textColor,
                                  fontWeight: FontWeight.w800,
                                  fontFamily: 'Montserrat',
                                  decoration: TextDecoration.none),
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                  SizedBox(height: 8.h,),
                  GestureDetector(
                    onTap: () async {
                     logic.onCancelButtonPressed();
                    },
                    child: Container(
                      width: 352.w,
                      height: 48.h,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                            begin: Alignment.bottomCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              Color.fromRGBO(248, 248, 248, 1),
                              Color.fromRGBO(228, 225, 219, 1),
                            ]),
                        borderRadius: BorderRadius.all(Radius.circular(6.r)),
                        border: Border.all(width: 1.w, color: Color(0xFFE4E1DB)),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            child: Text(
                              'Cancel'.tr,
                              style: TextStyle(
                                  fontSize: 14.sp,
                                  color: colorController.textColor,
                                  fontWeight: FontWeight.w800,
                                  fontFamily: 'Montserrat',
                                  decoration: TextDecoration.none),
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),


      ),
    );
  }

  //安卓指纹识别组件
  Widget finger(BuildContext context) {
    return SlideInUp(
      child: Container(
        height: 468.h,
        decoration: BoxDecoration(
          color: Color(0xFFF7F7F7),
          borderRadius: BorderRadius.only(
              topRight: Radius.circular(24.r),
              topLeft: Radius.circular(24.r)
          ),

        ),
        child: Column(
          children: [
            //头部横杠
            Container(
              margin: EdgeInsets.only(top: 16.h),
              width: 56.w,
              height: 5.h,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(90.r),
                  color: Color(0xFFbacE8E8E8)
              ),
            ),
            ///标题 和关闭按钮
            Container(
              height: 32.h,
              margin: EdgeInsets.only(top: 29.h,),
              child: Row(
                children: [

                  Expanded(
                    flex: 1,
                    child: GestureDetector(
                      onTap: () {
                        print('密码登录');
                        logic.modeSwitching();
                      },
                      child: SvgPicture.asset('assets/wallet_page/fingerboard.svg',
                        width: 32.w,),),),
                  Expanded(
                      flex: 1,
                      child: Obx(() {
                        return FittedBox(
                            child: Text(
                                state.mobileType.value == 'ios' ? 'ios' : 'Biology Verification',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontWeight: FontWeight.w700,
                                  fontSize: 18.sp,
                                  color: colorController.textColor,
                                )
                            )
                        );
                      })),
                  Expanded(
                      flex: 1,
                      child: GestureDetector(
                        onTap: () {
                          Navigator.pop(context);
                        },
                        child: Container(
                          padding: EdgeInsets.only(right: 23.w),
                          alignment: Alignment.centerRight,
                          child: Container(
                            child: SvgPicture.asset('assets/wallet_page/x.svg',
                              width: 24.w,),
                          ),
                        ),
                      )),
                ],
              ),
            ),

            /// 中间图标和文字
            Container(
              // height: 160.h,
              margin: EdgeInsets.only(bottom: 47.h, top: 47.h),
              child: Column(
                children: [
                  GestureDetector(
                      onTap: (){
                        logic.goCheckBiometri();
                      },
                      child:Image.asset(
                        state.mobileType.value == 'ios' ? 'ios' : 'assets/images/biology.png',
                        width: 95.w,)),
                  SizedBox(height: 17.h,),
                  Container(
                    width: 225.w,
                    child: Text(
                      state.mobileType.value == 'ios' ? 'ios' : 'Is the device supporting biology login enabled?',

                      textAlign:TextAlign.center,
                      style: TextStyle(fontSize: 12.sp,fontWeight: FontWeight.w600,color: colorController.textColor),),
                  ),
                  SizedBox(height: 20.h,),
                  Container(
                    height: 20.h,
                    alignment: Alignment.center,
                    child: Obx(() {
                      return
                        !state.biologyState.value ?
                        Text(
                          '验证失败，请重新验证',
                          style: XTextStyle.super_8(
                              XColor.neutral13),
                        ) : SizedBox();
                    }),
                  ),
                  GestureDetector(
                    onTap: () {
                    },
                    child: Container(
                      // margin: EdgeInsets.only(bottom: 35.h),
                      width: 352.w,
                      height: 48.h,
                      decoration: BoxDecoration(
                        color: Color(0xFFFF5E0F),
                        borderRadius: BorderRadius.all(Radius.circular(6.r)),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            child: Text(
                              'Confirm'.tr,
                              style: TextStyle(
                                  fontSize: 14.sp,
                                  color: colorController.textColor,
                                  fontWeight: FontWeight.w800,
                                  fontFamily: 'Montserrat',
                                  decoration: TextDecoration.none),
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                  SizedBox(height: 8.h,),
                  GestureDetector(
                    onTap: () async {
                      logic.onCancelButtonPressed();
                    },
                    child: Container(
                      width: 352.w,
                      height: 48.h,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                            begin: Alignment.bottomCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              Color.fromRGBO(248, 248, 248, 1),
                              Color.fromRGBO(228, 225, 219, 1),
                            ]),
                        borderRadius: BorderRadius.all(Radius.circular(6.r)),
                        border: Border.all(width: 1.w, color: Color(0xFFE4E1DB)),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Container(
                            child: Text(
                              'Cancel'.tr,
                              style: TextStyle(
                                  fontSize: 14.sp,
                                  color: colorController.textColor,
                                  fontWeight: FontWeight.w800,
                                  fontFamily: 'Montserrat',
                                  decoration: TextDecoration.none),
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),


      ),
    );
  }

  // 密码登录
  Widget passwordBox(BuildContext context) {
    return SlideInUp(
      child: Container(
        decoration: BoxDecoration(
          color: Color(0xFFF7F7F7),
          borderRadius: BorderRadius.only(
              topRight: Radius.circular(24.r),
              topLeft: Radius.circular(24.r)
          ),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ///标题 和关闭按钮
            Container(
              height: 32.h,
              margin: EdgeInsets.only(top: 29.h,),
              child: Row(
                children: [
                  Expanded(
                      flex: 1,
                      child: Obx(() {
                        return
                          state.biologyState.value ?
                          GestureDetector(
                            onTap: () {
                              print('切换到面部识别');
                              logic.modeSwitching();
                            },
                            child: Container(
                              alignment: Alignment.center,
                              child: Obx(() {
                                return
                                  state.mobileType.value == 'android' ?
                                  Icon(Icons.fingerprint_rounded, size: 30.w,
                                    color: Color(0xFF000000),):
                                  SvgPicture.asset(
                                    'assets/wallet_page/iOSAnimation.svg', width: 50.w,);
                              }),
                            ),
                          ) : SizedBox();
                      })),
                  Expanded(
                      flex: 2,
                      child: Text(
                          'password',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              fontWeight: FontWeight.w700,
                              fontSize: 18.sp,
                              color: Color(0xFF121212)
                          )
                      )),
                  Expanded(
                      flex: 1,
                      child: GestureDetector(
                        onTap: () {
                          print('关闭');
                          Navigator.pop(context); // 添加这行代码，关闭弹窗
                        },
                        child: Container(
                          padding: EdgeInsets.only(right: 23.w),
                          alignment: Alignment.centerRight,
                          child: Container(
                            child: SvgPicture.asset('assets/wallet_page/x.svg',
                              width: 24.w,),
                          ),
                        ),
                      )),
                ],
              ),
            ),
            SizedBox(height: 46.h,),
            Row(
              children: [
                Container(
                  padding: EdgeInsets.only(
                      left: 32.w, right: 32.w),
                  child: Text('Set a 6-digit numeric password'),
                ),
              ],
            ),
            Container(
              height: 65.h,
              margin: EdgeInsets.only(top: 12.h, bottom: 10.h),
              padding: EdgeInsets.only(
                  left: 32.w, right: 32.w),
              child: Obx(() {
                return PinInputTextField(
                  // controller: logic.passwordController,
                    focusNode: logic.focusNodeConfirm,// 设置 focusNode
                    autoFocus: true,
                    pinLength: 6,
                    keyboardType: TextInputType.number,
                    // onChanged: (cha) {
                    //   print(cha);
                    //   logic.checkPassword(inputPassword: logic.passwordController.text);
                    // },


                    onChanged: (value) {
                      logic.checkPassword(inputPassword: value); // 每次输入都进行密码验证操作
                      if (value.length != 6) {
                        state.passwordLoginState(true); // 设置密码图标为默认状态
                        logic.showErrorText(false); // 隐藏错误提示文本
                      } else {
                        if (!state.passwordLoginState.value) {
                          state.passwordLoginState(false); // 密码错误，设置密码图标为错误状态
                          logic.showErrorText(true); // 显示错误提示文本
                        } else {
                          state.passwordLoginState(false); // 密码正确，设置密码图标为正确状态
                          logic.showErrorText(false); // 隐藏错误提示文本
                        }
                      }
                    },
                    decoration: BoxLooseDecoration(
                      textStyle: TextStyle(
                          height: 2,
                          color: XColor.neutral04,
                          fontSize: 34.sp,
                          fontWeight: FontWeight.w400),
                      obscureStyle: ObscureStyle(
                          isTextObscure: true,
                          obscureText: '*'),
                      radius: Radius.circular(10.r),
                      gapSpace: 15,
                      strokeWidth: 1,
                      strokeColorBuilder:
                      PinListenColorBuilder(
                          !state.biologyState.value
                              ? Color(0xFFC0BBB3)
                              : Color(0xFFC0BBB3),
                          Color(0xFF000000).withOpacity(.1)),
                      bgColorBuilder:
                      PinListenColorBuilder(
                          !state.biologyState.value
                              ? Colors.transparent
                              : Color(0xFFEEEEEE).withOpacity(
                              .1),
                          Color(0xFFFFFFFF).withOpacity(1)),
                    ));
              }),
            ),
            Container(
              height: 20.h,
              padding: EdgeInsets.only(
                  left: 32.w, right: 32.w),
              alignment: Alignment.centerLeft,
              child: Obx(() {
                return logic.showErrorText.value
                    ? Text(
                  'Please enter the correct password',
                  // style: XTextStyle.super_8(
                  //     Color(0xFFFF3C3C)),
                  style: TextStyle(
                      fontWeight: FontWeight.w400,
                      fontSize: 8.sp,
                      color: Color(0xFFFF3C3C)),
                )
                    : SizedBox();
              }),
            )
          ],
        ),


      ),
    );
  }
}
